import { IServerRender } from 'umi';
export = render;
export as namespace render;
declare const render: IServerRender;